from datetime import datetime, date
from decimal import Decimal, InvalidOperation

from django.db.models import Sum
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse

from .models import (
    Season,
    TournamentType,
    Tournament,
    TournamentEntry,
    TournamentResult,
    Player,
    SeasonInitialPoints,
)


# =========================
# Função auxiliar de ranking
# =========================
def _build_ranking_for_season(season):
    """
    Monta o ranking da temporada com:
    - pontos iniciais
    - pontos de torneios (pontos_finais)
    - pontos de participação
    Também calcula:
    - posição (rank)
    - flag de empate em pontos
    """

    # 1) Pontos de resultados de torneios
    resultados = (
        TournamentResult.objects
        .filter(tournament__season=season)
        .values("player__id", "player__nome", "player__apelido")
        .annotate(total_resultado=Sum("pontos_finais"))
    )

    # 2) Pontos de participação
    participacoes = (
        TournamentEntry.objects
        .filter(tournament__season=season)
        .values("player__id")
        .annotate(total_participacao=Sum("pontos_participacao"))
    )

    # 3) Pontos iniciais (migração / bônus)
    iniciais = (
        SeasonInitialPoints.objects
        .filter(season=season)
        .values("player__id", "player__nome", "player__apelido")
        .annotate(total_iniciais=Sum("pontos_iniciais"))
    )

    # ---- junta tudo num dicionário por player_id ----
    ranking_dict = {}

    # Resultados de torneio
    for r in resultados:
        pid = r["player__id"]
        ranking_dict[pid] = {
            "nome": r["player__apelido"] or r["player__nome"],
            "pontos_resultado": r["total_resultado"] or 0,
            "pontos_participacao": 0,
            "pontos_iniciais": 0,
        }

    # Participação
    for p in participacoes:
        pid = p["player__id"]
        if pid in ranking_dict:
            ranking_dict[pid]["pontos_participacao"] = p["total_participacao"]
        else:
            ranking_dict[pid] = {
                "nome": "Jogador desconhecido",
                "pontos_resultado": 0,
                "pontos_participacao": p["total_participacao"],
                "pontos_iniciais": 0,
            }

    # Pontos iniciais
    for i in iniciais:
        pid = i["player__id"]
        nome = i["player__apelido"] or i["player__nome"]
        if pid in ranking_dict:
            ranking_dict[pid]["pontos_iniciais"] = i["total_iniciais"]
        else:
            ranking_dict[pid] = {
                "nome": nome,
                "pontos_resultado": 0,
                "pontos_participacao": 0,
                "pontos_iniciais": i["total_iniciais"],
            }

    # ---- monta lista, calcula total e ordena com critério claro ----
    ranking_lista = []
    for pid, jogador in ranking_dict.items():
        total = (
            (jogador["pontos_resultado"] or 0)
            + (jogador["pontos_participacao"] or 0)
            + (jogador["pontos_iniciais"] or 0)
        )
        ranking_lista.append({
            "player_id": pid,
            "nome": jogador["nome"],
            "pontos": total,
            "pontos_resultado": jogador["pontos_resultado"] or 0,
            "pontos_participacao": jogador["pontos_participacao"] or 0,
            "pontos_iniciais": jogador["pontos_iniciais"] or 0,
        })

    # Critério de desempate:
    # 1) pontos totais desc
    # 2) mais pontos de torneios desc
    # 3) mais pontos iniciais desc
    # 4) nome alfabético
    ranking_lista.sort(
        key=lambda x: (
            -(x["pontos"]),
            -(x["pontos_resultado"]),
            -(x["pontos_iniciais"]),
            x["nome"].lower(),
        )
    )

    # ---- calcula posição (rank) e flag de empate em pontos ----
    last_pontos = None
    last_rank = 0
    index = 0

    # conta quantos têm cada pontuação (pra marcar empate visualmente)
    pontos_count = {}
    for item in ranking_lista:
        pts = item["pontos"]
        pontos_count[pts] = pontos_count.get(pts, 0) + 1

    for item in ranking_lista:
        index += 1
        if last_pontos is None or item["pontos"] < last_pontos:
            rank = index
        else:
            # mesma pontuação total => mesma posição
            rank = last_rank

        item["posicao"] = rank
        item["empatado"] = pontos_count[item["pontos"]] > 1

        last_pontos = item["pontos"]
        last_rank = rank

    return ranking_lista


# =========================
# Ranking / Telão
# =========================
def ranking_season(request, season_id):
    season = get_object_or_404(Season, id=season_id)
    ranking_lista = _build_ranking_for_season(season)

    return render(
        request,
        "ranking.html",
        {
            "season": season,
            "ranking": ranking_lista,
        },
    )


def tv_ranking_season(request, season_id):
    season = get_object_or_404(Season, id=season_id)
    ranking_lista = _build_ranking_for_season(season)

    return render(
        request,
        "tv_ranking.html",
        {
            "season": season,
            "ranking": ranking_lista,
        },
    )


# =========================
# Evolução do jogador na temporada (NOVO)
# =========================
def player_progress_season(request, season_id, player_id):
    """
    Mostra a evolução de pontos de um jogador na temporada, rodada a rodada
    (cada torneio = uma 'rodada'), incluindo os pontos iniciais.
    """
    season = get_object_or_404(Season, id=season_id)
    player = get_object_or_404(Player, id=player_id)

    # pontos iniciais desse jogador na temporada
    sip = SeasonInitialPoints.objects.filter(
        season=season,
        player=player,
    ).first()
    pontos_iniciais = sip.pontos_iniciais if sip else 0

    # torneios da temporada, em ordem cronológica
    torneios = (
        Tournament.objects
        .filter(season=season)
        .order_by("data")
    )

    progresso = []
    acumulado = pontos_iniciais

    # se tiver pontos iniciais, registra como "linha 0"
    if pontos_iniciais != 0:
        progresso.append({
            "tipo": "iniciais",
            "descricao": "Pontos iniciais da temporada",
            "data": None,
            "torneio": None,
            "pontos_rodada": pontos_iniciais,
            "acumulado": acumulado,
        })

    for t in torneios:
        result = TournamentResult.objects.filter(
            tournament=t,
            player=player,
        ).first()

        pts_rodada = result.pontos_finais if result else 0
        if pts_rodada != 0 or True:
            acumulado += pts_rodada
            progresso.append({
                "tipo": "torneio",
                "descricao": t.nome,
                "data": t.data,
                "torneio": t,
                "pontos_rodada": pts_rodada,
                "acumulado": acumulado,
            })

    # total final esperado na temporada (pra conferência visual)
    total_final = acumulado

    return render(
        request,
        "player_progress.html",
        {
            "season": season,
            "player": player,
            "progresso": progresso,
            "pontos_iniciais": pontos_iniciais,
            "total_final": total_final,
        },
    )


# =========================
# Painel do organizador
# =========================
def painel_home(request):
    seasons = Season.objects.order_by("-data_inicio")

    return render(
        request,
        "painel_home.html",
        {
            "seasons": seasons,
        },
    )


# =========================
# CRUD de Temporadas
# =========================
def seasons_list(request):
    seasons = Season.objects.order_by("-data_inicio")
    return render(
        request,
        "seasons_list.html",
        {"seasons": seasons},
    )


def season_create(request):
    if request.method == "POST":
        nome = request.POST.get("nome", "").strip()
        data_inicio_str = request.POST.get("data_inicio", "").strip()
        data_fim_str = request.POST.get("data_fim", "").strip()
        ativo = request.POST.get("ativo") == "on"

        if nome and data_inicio_str and data_fim_str:
            try:
                data_inicio = date.fromisoformat(data_inicio_str)
                data_fim = date.fromisoformat(data_fim_str)
            except ValueError:
                data_inicio = date.today()
                data_fim = date.today()

            Season.objects.create(
                nome=nome,
                data_inicio=data_inicio,
                data_fim=data_fim,
                ativo=ativo,
            )

        return HttpResponseRedirect(reverse("seasons_list"))

    return render(request, "season_form.html", {"season": None})


def season_edit(request, season_id):
    season = get_object_or_404(Season, id=season_id)

    if request.method == "POST":
        season.nome = request.POST.get("nome", "").strip()
        data_inicio_str = request.POST.get("data_inicio", "").strip()
        data_fim_str = request.POST.get("data_fim", "").strip()
        season.ativo = request.POST.get("ativo") == "on"

        try:
            if data_inicio_str:
                season.data_inicio = date.fromisoformat(data_inicio_str)
            if data_fim_str:
                season.data_fim = date.fromisoformat(data_fim_str)
        except ValueError:
            pass

        season.save()
        return HttpResponseRedirect(reverse("seasons_list"))

    return render(
        request,
        "season_form.html",
        {"season": season},
    )


# =========================
# Pontos iniciais da temporada
# =========================
def season_initial_points(request, season_id):
    """
    Tela para lançar / editar pontos iniciais de cada jogador na temporada.
    """
    season = get_object_or_404(Season, id=season_id)
    mensagem = None

    players = Player.objects.filter(ativo=True).order_by("nome")

    if request.method == "POST":
        for player in players:
            field_name = f"pontos_{player.id}"
            val_str = request.POST.get(field_name, "").strip()

            if val_str == "":
                # campo em branco → apaga, se existir
                SeasonInitialPoints.objects.filter(
                    season=season,
                    player=player,
                ).delete()
                continue

            try:
                pontos = int(val_str)
            except ValueError:
                pontos = 0

            sip, created = SeasonInitialPoints.objects.get_or_create(
                season=season,
                player=player,
                defaults={"pontos_iniciais": pontos},
            )
            if not created:
                sip.pontos_iniciais = pontos
                sip.save()

        mensagem = "Pontos iniciais salvos com sucesso."

    # monta dicionário para preencher os inputs
    iniciais_map = {
        sip.player_id: sip.pontos_iniciais
        for sip in SeasonInitialPoints.objects.filter(season=season)
    }

    linhas = []
    for p in players:
        linhas.append(
            {
                "player": p,
                "pontos": iniciais_map.get(p.id, 0),
            }
        )

    return render(
        request,
        "season_initial_points.html",
        {
            "season": season,
            "linhas": linhas,
            "mensagem": mensagem,
        },
    )


# =========================
# CRUD de Tipos de Torneio
# =========================
def tournament_types_list(request):
    tipos = TournamentType.objects.order_by("nome")
    return render(
        request,
        "tournament_types_list.html",
        {"tipos": tipos},
    )


def tournament_type_create(request):
    if request.method == "POST":
        nome = request.POST.get("nome", "").strip()
        descricao = request.POST.get("descricao", "").strip()
        multiplicador_str = request.POST.get("multiplicador", "1").strip()
        usa_regras_padrao = request.POST.get("usa_regras_padrao") == "on"

        if not multiplicador_str:
            multiplicador_str = "1"

        try:
            multiplicador = Decimal(multiplicador_str.replace(",", "."))
        except InvalidOperation:
            multiplicador = Decimal("1")

        if nome:
            TournamentType.objects.create(
                nome=nome,
                descricao=descricao or None,
                multiplicador_pontos=multiplicador,
                usa_regras_padrao=usa_regras_padrao,
            )

        return HttpResponseRedirect(reverse("tournament_types_list"))

    return render(
        request,
        "tournament_type_form.html",
        {"tipo": None},
    )


def tournament_type_edit(request, tipo_id):
    tipo = get_object_or_404(TournamentType, id=tipo_id)

    if request.method == "POST":
        tipo.nome = request.POST.get("nome", "").strip()
        tipo.descricao = request.POST.get("descricao", "").strip() or None
        multiplicador_str = request.POST.get("multiplicador", "1").strip()
        tipo.usa_regras_padrao = request.POST.get("usa_regras_padrao") == "on"

        if not multiplicador_str:
            multiplicador_str = "1"

        try:
            tipo.multiplicador_pontos = Decimal(
                multiplicador_str.replace(",", ".")
            )
        except InvalidOperation:
            pass

        tipo.save()
        return HttpResponseRedirect(reverse("tournament_types_list"))

    return render(
        request,
        "tournament_type_form.html",
        {"tipo": tipo},
    )


# =========================
# Torneios da temporada + CRUD
# =========================
def season_tournaments(request, season_id):
    season = get_object_or_404(Season, id=season_id)
    tournaments = (
        Tournament.objects
        .filter(season=season)
        .order_by("-data")
    )

    return render(
        request,
        "tournaments_list.html",
        {
            "season": season,
            "tournaments": tournaments,
        },
    )


def tournament_create(request, season_id):
    season = get_object_or_404(Season, id=season_id)
    tipos = TournamentType.objects.order_by("nome")

    if request.method == "POST":
        nome = request.POST.get("nome", "").strip()
        data_str = request.POST.get("data", "").strip()
        tipo_id = request.POST.get("tipo_id")
        status = request.POST.get("status", "AGENDADO")

        buy_in_str = request.POST.get("buy_in", "").strip()
        garantido_str = request.POST.get("garantido", "").strip()

        if nome and data_str and tipo_id:
            try:
                data = datetime.fromisoformat(data_str)
            except ValueError:
                data = datetime.now()

            tipo = get_object_or_404(TournamentType, id=int(tipo_id))

            buy_in = None
            garantido = None

            if buy_in_str:
                try:
                    buy_in = Decimal(buy_in_str.replace(",", "."))
                except InvalidOperation:
                    buy_in = None

            if garantido_str:
                try:
                    garantido = Decimal(garantido_str.replace(",", "."))
                except InvalidOperation:
                    garantido = None

            Tournament.objects.create(
                nome=nome,
                data=data,
                season=season,
                tipo=tipo,
                buy_in=buy_in,
                garantido=garantido,
                status=status,
            )

        return HttpResponseRedirect(
            reverse("season_tournaments", args=[season.id])
        )

    return render(
        request,
        "tournament_form.html",
        {
            "season": season,
            "tipos": tipos,
            "tournament": None,
        },
    )


def tournament_edit(request, tournament_id):
    tournament = get_object_or_404(Tournament, id=tournament_id)
    season = tournament.season
    tipos = TournamentType.objects.order_by("nome")

    if request.method == "POST":
        tournament.nome = request.POST.get("nome", "").strip()
        data_str = request.POST.get("data", "").strip()
        tipo_id = request.POST.get("tipo_id")
        tournament.status = request.POST.get("status", "AGENDADO")

        buy_in_str = request.POST.get("buy_in", "").strip()
        garantido_str = request.POST.get("garantido", "").strip()

        if data_str:
            try:
                tournament.data = datetime.fromisoformat(data_str)
            except ValueError:
                pass

        if tipo_id:
            tournament.tipo = get_object_or_404(TournamentType, id=int(tipo_id))

        if buy_in_str:
            try:
                tournament.buy_in = Decimal(buy_in_str.replace(",", "."))
            except InvalidOperation:
                pass
        else:
            tournament.buy_in = None

        if garantido_str:
            try:
                tournament.garantido = Decimal(garantido_str.replace(",", "."))
            except InvalidOperation:
                pass
        else:
            tournament.garantido = None

        tournament.save()
        return HttpResponseRedirect(
            reverse("season_tournaments", args=[season.id])
        )

    data_str = tournament.data.strftime("%Y-%m-%dT%H:%M")

    return render(
        request,
        "tournament_form.html",
        {
            "season": season,
            "tipos": tipos,
            "tournament": tournament,
            "data_str": data_str,
        },
    )


# =========================
# Jogadores (CRUD)
# =========================
def players_list(request):
    players = Player.objects.order_by("nome")

    return render(
        request,
        "players_list.html",
        {
            "players": players,
        },
    )


def player_create(request):
    if request.method == "POST":
        nome = request.POST.get("nome", "").strip()
        apelido = request.POST.get("apelido", "").strip()
        cpf = request.POST.get("cpf", "").strip()
        telefone = request.POST.get("telefone", "").strip()
        ativo = request.POST.get("ativo") == "on"

        if nome:
            Player.objects.create(
                nome=nome,
                apelido=apelido or None,
                cpf=cpf or None,
                telefone=telefone or None,
                ativo=ativo,
            )

        return HttpResponseRedirect(reverse("players_list"))

    return render(request, "player_form.html", {"player": None})


def player_edit(request, player_id):
    player = get_object_or_404(Player, id=player_id)

    if request.method == "POST":
        player.nome = request.POST.get("nome", "").strip()
        player.apelido = request.POST.get("apelido", "").strip() or None
        player.cpf = request.POST.get("cpf", "").strip() or None
        player.telefone = request.POST.get("telefone", "").strip() or None
        player.ativo = request.POST.get("ativo") == "on"
        player.save()

        return HttpResponseRedirect(reverse("players_list"))

    return render(
        request,
        "player_form.html",
        {
            "player": player,
        },
    )


# =========================
# Jogadores no torneio
# =========================
def tournament_entries_manage(request, tournament_id):
    """
    Gerencia jogadores inscritos no torneio.

    Ao remover jogadores, também removemos os TournamentResult
    correspondentes, para que a pontuação do ranking seja coerente.
    """
    tournament = get_object_or_404(Tournament, id=tournament_id)
    season = tournament.season
    mensagem = None

    if request.method == "POST":
        # Adicionar jogador
        if "add_player" in request.POST:
            player_id_str = request.POST.get("novo_player_id")
            if player_id_str:
                try:
                    player = Player.objects.filter(
                        id=int(player_id_str),
                        ativo=True,
                    ).first()
                    if player:
                        TournamentEntry.objects.get_or_create(
                            tournament=tournament,
                            player=player,
                        )
                except ValueError:
                    pass

            return HttpResponseRedirect(
                reverse("tournament_entries_manage", args=[tournament.id]) + "?ok=1"
            )

        # Remover selecionados
        if "remove_selected" in request.POST:
            ids = request.POST.getlist("remover_entry_id")

            entries_qs = TournamentEntry.objects.filter(
                tournament=tournament,
                id__in=ids,
            )
            player_ids = list(
                entries_qs.values_list("player_id", flat=True)
            )

            if player_ids:
                TournamentResult.objects.filter(
                    tournament=tournament,
                    player_id__in=player_ids,
                ).delete()

            entries_qs.delete()

            return HttpResponseRedirect(
                reverse("tournament_entries_manage", args=[tournament.id]) + "?ok=1"
            )

    if request.GET.get("ok"):
        mensagem = "Alterações salvas com sucesso."

    entries = (
        TournamentEntry.objects
        .filter(tournament=tournament)
        .select_related("player")
        .order_by("player__nome")
    )

    ids_inscritos = [e.player_id for e in entries]

    players_disponiveis = (
        Player.objects
        .filter(ativo=True)
        .exclude(id__in=ids_inscritos)
        .order_by("nome")
    )

    return render(
        request,
        "tournament_entries.html",
        {
            "tournament": tournament,
            "season": season,
            "entries": entries,
            "players_disponiveis": players_disponiveis,
            "mensagem": mensagem,
        },
    )


def tournament_results(request, tournament_id):
    tournament = get_object_or_404(Tournament, id=tournament_id)
    season = tournament.season
    mensagem = None

    if request.method == "POST":
        entries = (
            TournamentEntry.objects
            .filter(tournament=tournament)
            .select_related("player")
        )

        for entry in entries:
            player = entry.player
            pid = player.id

            participou = request.POST.get(f"participou_{pid}") is not None
            confirmou = request.POST.get(f"confirmou_{pid}") is not None
            timechip = request.POST.get(f"timechip_{pid}") is not None

            pos_str = request.POST.get(f"pos_{pid}", "").strip()
            ajuste_str = request.POST.get(f"ajuste_{pid}", "").strip()

            entry.participou = participou
            entry.confirmou_presenca = confirmou
            entry.usou_time_chip = timechip
            entry.save()

            result = TournamentResult.objects.filter(
                tournament=tournament,
                player=player,
            ).first()

            if pos_str:
                pos = int(pos_str)
                ajuste = int(ajuste_str) if ajuste_str else 0

                if result is None:
                    result = TournamentResult(
                        tournament=tournament,
                        player=player,
                    )

                result.posicao = pos
                result.pontos_bonus = 0
                result.pontos_ajuste_deal = ajuste
                result.save()
            else:
                if result:
                    result.delete()

        tournament.recalcular_pontuacao()

        return HttpResponseRedirect(
            reverse("tournament_results", args=[tournament.id]) + "?ok=1"
        )

    if request.GET.get("ok"):
        mensagem = "Dados salvos e pontos recalculados com sucesso."

    entries = (
        TournamentEntry.objects
        .filter(tournament=tournament)
        .select_related("player")
        .order_by("player__nome")
    )

    linhas = []

    for entry in entries:
        result = TournamentResult.objects.filter(
            tournament=tournament,
            player=entry.player,
        ).first()

        linhas.append(
            {
                "player": entry.player,
                "entry": entry,
                "result": result,
            }
        )

    return render(
        request,
        "tournament_results.html",
        {
            "tournament": tournament,
            "season": season,
            "linhas": linhas,
            "mensagem": mensagem,
        },
    )
