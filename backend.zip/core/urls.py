from django.urls import path
from .views import (
    ranking_season,
    tv_ranking_season,
    painel_home,

    # Temporadas
    seasons_list,
    season_create,
    season_edit,
    season_initial_points,
    player_progress_season,

    # Tipos de torneio
    tournament_types_list,
    tournament_type_create,
    tournament_type_edit,

    # Torneios
    season_tournaments,
    tournament_create,
    tournament_edit,
    tournament_entries_manage,
    tournament_results,

    # Jogadores
    players_list,
    player_create,
    player_edit,
)

urlpatterns = [
    path("", painel_home, name="painel_home"),

    path("ranking/<int:season_id>/", ranking_season, name="ranking_season"),
    path("tv/ranking/<int:season_id>/", tv_ranking_season, name="tv_ranking_season"),

    # Temporadas
    path("temporadas/", seasons_list, name="seasons_list"),
    path("temporadas/nova/", season_create, name="season_create"),
    path("temporadas/editar/<int:season_id>/", season_edit, name="season_edit"),
    path(
        "temporadas/<int:season_id>/pontos-iniciais/",
        season_initial_points,
        name="season_initial_points",
    ),
    path(
        "temporadas/<int:season_id>/jogador/<int:player_id>/evolucao/",
        player_progress_season,
        name="player_progress_season",
    ),

    # Tipos de torneio
    path("tipos-torneio/", tournament_types_list, name="tournament_types_list"),
    path("tipos-torneio/novo/", tournament_type_create, name="tournament_type_create"),
    path(
        "tipos-torneio/editar/<int:tipo_id>/",
        tournament_type_edit,
        name="tournament_type_edit",
    ),

    # Torneios
    path(
        "season/<int:season_id>/torneios/",
        season_tournaments,
        name="season_tournaments",
    ),
    path(
        "season/<int:season_id>/torneios/novo/",
        tournament_create,
        name="tournament_create",
    ),
    path(
        "torneio/<int:tournament_id>/editar/",
        tournament_edit,
        name="tournament_edit",
    ),
    path(
        "torneio/<int:tournament_id>/jogadores/",
        tournament_entries_manage,
        name="tournament_entries_manage",
    ),
    path(
        "torneio/<int:tournament_id>/lancamento/",
        tournament_results,
        name="tournament_results",
    ),

    # Jogadores
    path("jogadores/", players_list, name="players_list"),
    path("jogadores/novo/", player_create, name="player_create"),
    path("jogadores/editar/<int:player_id>/", player_edit, name="player_edit"),
]
